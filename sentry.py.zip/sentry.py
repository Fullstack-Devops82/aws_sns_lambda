import os
import json
import boto3
from ipaddress import ip_network, ip_address

# Define the list of CIDR
ip_range = ['10.10.0.0/16', '20.0.0.0/8']
all_ip = '0.0.0.0/0'
prefix32 = '32'

# ===============================================================================
def lambda_handler(event, context):
    # Ensure that we have an event name to evaluate.
    cidr = str(event['detail']['requestParameters']['ipPermissions']['items'][0]['ipRanges']['items'][0]['cidrIp'])
    cidrIp = cidr.split('/')
    rangeIn = False
    for ip in ip_range:
        net = ip_network(ip)
        if (ip_address(cidrIp[0]) in net):
            rangeIn = True
            break
    
    if cidr == all_ip:
        rangeIn = True
    
    if cidrIp[1] == prefix32:
        rangeIn = False

    if rangeIn == False or 'detail' not in event or ('detail' in event and 'eventName' not in event['detail']):
        print('CIDR is not in range.')
        return {"Result": "Failure", "Message": "Lambda not triggered by an event"}

    if (event['detail']['eventName'] == 'AuthorizeSecurityGroupIngress' or event['detail']['eventName'] == 'AuthorizeSecurityGroupEgress'
         or event['detail']['eventName'] == 'RevokeSecurityGroupIngress' or event['detail']['eventName'] == 'RevokeSecurityGroupEgress'):
        message = "Open-Ingress Alert: Ingress rule modified from security group: {} that was added by {}: {}".format(
            event['detail']['requestParameters']['groupId'],
            event['detail']['userIdentity']['arn'],
            json.dumps('Roles: ' + cidr)
        )

        myArn = os.environ['sns_topic_arn']
        client = boto3.client('sns')
        resp = client.publish(TargetArn=os.environ['sns_topic_arn'], Message=json.dumps({'default': json.dumps(message)}), MessageStructure='json')
